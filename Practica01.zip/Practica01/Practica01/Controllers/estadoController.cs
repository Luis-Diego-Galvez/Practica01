using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using Practica01.Models;

namespace Practica01.Controllers
{
    [ApiController] 
    public class equiposController : ControllerBase
    {
        private readonly Practica01Context _contexto;

        public equiposController(Practica01Context miContexto) {
            this._contexto = miContexto;
        }

        [HttpGet]
        [Route("api/equipos")]
        public IActionResult Get(){
            var marcasList = _contexto.equipos;
            if(marcasList.Count>0){
                return Ok(equiposList);
            }
            return NotFound();            
        } 

    }
}
using System;
using System.ComponentModel.DataAnnotations;
namespace Practica01.Models
{
    public class estado{
         [Key]
        public int estado_equipo_id { get; set; }
    }
}
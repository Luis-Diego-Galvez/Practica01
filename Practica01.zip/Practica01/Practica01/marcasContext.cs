using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
using Practica01.Models;

namespace  Practica01
{
    public class marcasContext : DbContext
    {
        public marcasContext(DbContextOptions<maracasContext> options) : base(options)
        {            
        }

        public DbSet<equipos> marcas {get; set;}
    }
}
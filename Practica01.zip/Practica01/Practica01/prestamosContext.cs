using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.SqlServer;
using Practica01.Models;

namespace  Practica01
{
    public class prestamosContext : DbContext
    {
        public prestamosContext(DbContextOptions<prestamosContext> options) : base(options)
        {            
        }

        public DbSet<equipos> equipos {get; set;}
    }
}